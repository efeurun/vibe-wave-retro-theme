<?php get_header(); ?>

<div class="site-container">
    <div class="content-area">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <article class="post">
                    <h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <div class="post-meta">
                        <span class="date"><?php the_time('F j, Y'); ?></span> by 
                        <span class="author"><?php the_author(); ?></span> in
                        <span class="categories"><?php the_category(', '); ?></span>
                    </div>
                    <div class="post-content">
                        <?php the_excerpt(); ?>
                    </div>
                    <div class="read-more">
                        <a href="<?php the_permalink(); ?>">Read More &raquo;</a>
                    </div>
                </article>
            <?php endwhile; ?>
            
            <div class="pagination">
                <?php echo paginate_links(); ?>
            </div>
        <?php else : ?>
            <h2>No posts found</h2>
            <p>Sorry, no posts matched your criteria.</p>
        <?php endif; ?>
    </div>
    
    <?php get_sidebar(); ?>
</div>

<?php get_footer(); ?>
